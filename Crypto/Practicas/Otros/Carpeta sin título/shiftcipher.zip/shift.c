#include"shiftcipher.h"
#include<stdio.h>
#include<math.h>

//FILE *arch;
int largo, key, x, longitud = 0, num_letra[100], men_encrip[100], imprimir, tam, tam1;
char letra= 'A',numero[26];
for(i=0; i<26; i++){
		numero[i]=letra++;
	}

/*------------Descifrado de Shift Cipher-----------*/
/*void descifrar()
{
	
}*/

/*------------Cifrado de Shift Cipher-----------*/
void encriptar(char *c, int k)
{
	
	tam=sizeof(c);
	for(largo = 0; largo<tam; largo++)
	{
		for(x = 0; x < 26; x++)
		{
			letra++;
			numero[x] = letra;
			if(c[largo] != ' ')
			{
				if(c[largo] == numero[x])
				{
					num_letra[largo] = x;
					men_encrip[largo] = (num_letra[largo] + k) % 26;
				}
			}
		}
	}
	tam1=sizeof(men_encrip);
	for(imprimir = 0; imprimir <tam1; imprimir++)
	{
		printf("%c", men_encrip[imprimir]);
	}
}
