

/*------------Funciones Shift Cipher-----------*/
void descifrar();
void encriptar(c, k);


